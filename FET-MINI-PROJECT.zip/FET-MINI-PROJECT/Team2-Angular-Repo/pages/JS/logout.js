$(document).ready(function() {
    $("#logoutButton").click(function() {
       sessionStorage.clear(); 
    });
});